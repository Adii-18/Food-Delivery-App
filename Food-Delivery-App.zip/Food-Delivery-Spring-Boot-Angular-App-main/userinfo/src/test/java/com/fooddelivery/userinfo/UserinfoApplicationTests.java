package com.fooddelivery.userinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
