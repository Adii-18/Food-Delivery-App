package com.fooddelivery.foodcatalogue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodcatalogueApplicationTests {

	@Test
	void contextLoads() {
	}

}
