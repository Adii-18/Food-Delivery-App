export interface FoodItem {
  id?: number;
  name?: string;
  foodDescription?: string;
  isVeg?: boolean;
  price: number;
  restaurantId?: number;
  quantity: number;
}
